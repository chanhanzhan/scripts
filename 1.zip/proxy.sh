#!/bin/bash
while true; do 
curl -sSL https://vip.qiucg.com/proxy.txt?key=hffgcbcf > proxy.txt
curl -sSL https://vip.qiucg.com/cn.txt?key=hffgcbcf > cn.txt
curl -sSL https://vip.qiucg.com/http.txt?key=hffgcbcf > http.txt
sleep 1000 

done